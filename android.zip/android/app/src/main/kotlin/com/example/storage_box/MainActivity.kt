package com.Flutter.Material.Box

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
